import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Mapper;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Base64;
import javax.imageio.ImageIO;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ImageMapper extends Mapper<Object, Text, Text, IntWritable> {

    private final static IntWritable one = new IntWritable(1);
    private Map<String, Integer> colorCounts = new HashMap<>();

    // Define rounding factor for color precision (e.g., 10 for grouping colors by 10s)
    private final static int COLOR_PRECISION = 50;
    
    // Define sampling rate (process every nth pixel)
    private final static int PIXEL_SAMPLING_RATE = 20;

    // Maximum number of dominant colors to output
    private final static int MAX_DOMINANT_COLORS = 3;

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        try {
            // Decode the Base64 string to binary data
            byte[] imageData = Base64.getDecoder().decode(value.toString());

            // Convert byte array to BufferedImage
            ByteArrayInputStream bais = new ByteArrayInputStream(imageData);
            BufferedImage image = ImageIO.read(bais);

            if (image != null) {
                int width = image.getWidth();
                int height = image.getHeight();

                // Emit image dimensions
                context.write(new Text("Width: " + width), one);
                context.write(new Text("Height: " + height), one);

                // Extract and count colors with precision and sampling
                extractColorData(image);

                // Emit only the top N dominant colors
                emitDominantColors(context);

                // Clear the map for the next image
                colorCounts.clear();
            }
        } catch (Exception e) {
            // Print the exception stack trace
            e.printStackTrace();
        }
    }

    private void extractColorData(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();

        // Loop over pixels with sampling and color precision
        for (int y = 0; y < height; y += PIXEL_SAMPLING_RATE) {
            for (int x = 0; x < width; x += PIXEL_SAMPLING_RATE) {
                int rgb = image.getRGB(x, y);
                Color color = new Color(rgb);

                // Group similar colors by rounding RGB values (based on precision)
                int red = roundColorValue(color.getRed(), COLOR_PRECISION);
                int green = roundColorValue(color.getGreen(), COLOR_PRECISION);
                int blue = roundColorValue(color.getBlue(), COLOR_PRECISION);

                // Create a color string in the format "R,G,B"
                String colorKey = red + "," + green + "," + blue;

                // Update the color count
                colorCounts.put(colorKey, colorCounts.getOrDefault(colorKey, 0) + 1);
            }
        }
    }

    private int roundColorValue(int value, int precision) {
        return (value / precision) * precision;
    }

    private void emitDominantColors(Context context) throws IOException, InterruptedException {
        // Get the top N dominant colors by frequency
        Map<String, Integer> topColors = colorCounts.entrySet()
            .stream()
            .sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue())) // Sort by frequency
            .limit(MAX_DOMINANT_COLORS) // Keep only the top N colors
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                Map.Entry::getValue
            ));

        // Emit the dominant colors
        for (Map.Entry<String, Integer> entry : topColors.entrySet()) {
            context.write(new Text("Color: " + entry.getKey()), new IntWritable(entry.getValue()));
        }
    }
}
